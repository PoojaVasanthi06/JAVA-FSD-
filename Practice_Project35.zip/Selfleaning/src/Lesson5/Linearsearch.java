package Lesson5;

public class Linearsearch {

     static int linearSearch(int[] array, int target) {
        for (int i = 0; i < array.length; i++) {
            if (array[i] == target) {
                return i; 
            }
        }
        return -1;
    }

    public static void main(String[] args) {
        int[] array = {1, 5, 9, 12, 18, 24, 30};
        int target = 18;

         int result = linearSearch(array, target);

        if (result != -1) {
            System.out.println("Target " + target + " found at index " + result);
        } else {
            System.out.println("Target " + target + " not found in the array");
        }
    }
}

