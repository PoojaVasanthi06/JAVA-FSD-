package Practice;

public class Innerclass {
	
	class A{
	   void get(){
		   System.out.println("Inner class");
	   }
	}

	public static void main(String[] args) {
		Innerclass m =new Innerclass();
		Innerclass.A n =m.new A();
		n.get();
		m.put();
		C y =m.new C(){
			public void getter() {
	            System.out.println("Anonymous Inner Class");
			}
		};
		y.getter();

	}
	
	void put() {
		class B{
			void call() {
				System.out.println("Inner class inside method");
			}
		}
		B x=new B();
		x.call();
	}
	
	//anonymous inner class
	abstract class C{
		public abstract void getter();
	}

}
