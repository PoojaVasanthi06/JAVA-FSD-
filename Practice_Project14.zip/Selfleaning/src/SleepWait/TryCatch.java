package SleepWait;

public class TryCatch {

	@SuppressWarnings("null")
	public static void main(String[] args) {
		 try {
	            
	            String nullString = null;
	            System.out.println(nullString.length());  
	           
	            int[] array = new int[5];
	            System.out.println(array[10]);  
	        }
		 catch (NullPointerException e) {
	            System.out.println("Caught NullPointerException: " + e.getMessage());
	        } 
		 catch (ArrayIndexOutOfBoundsException e) {
	            System.out.println("Caught ArrayIndexOutOfBoundsException: " + e.getMessage());
	        }
	}

}
