package Practice;

public class Arraytypes {

	public static void main(String[] args) {
		System.out.println("Single dimentional array : ");
		int a[]= {10,20,30,40,50};
		for(int i=0;i<a.length;i++) {
			System.out.println(a[i]);
		}
		
		System.out.println("\nMulti dimentional array : ");
		int b[][]= {{10,20,30,40},{30,40},{60,70,80}};
		System.out.println("length of 1st row : "+b[0].length);
	}

}
