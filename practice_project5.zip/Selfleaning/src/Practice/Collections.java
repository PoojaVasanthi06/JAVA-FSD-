package Practice;

import java.util.*;

public class Collections {

	public static void main(String[] args) {
		System.out.println("1) Array list :");
		ArrayList<String> a = new ArrayList<String>();
		a.add("43");
		a.add("67");
		a.add("34");
		a.add("67");
		System.out.println(a);
		
		System.out.println("\n2) Linked list :");
		LinkedList<String> b = new LinkedList<String>();
        b.add("100");
        b.add("200");
        b.add("300");
        b.add("400");
		System.out.println(b);
		
		System.out.println("\n3) Hashset :");
	    HashSet<String> c = new HashSet<String>();
	    c.add("15");
	    c.add("69");
	    c.add("35");
	    c.add("90");
		System.out.println(c);

		System.out.println("\n4) LinkedHashSet :");
	    LinkedHashSet<String> d = new LinkedHashSet<String>();
	    d.add("100");
	    d.add("200");
	    d.add("300");
	    d.add("400");
		System.out.println(d);
		
		System.out.println("\n5) Vector :");
		Vector<String> f =new Vector<String>();
		f.addElement("15");
		f.addElement("69");
		f.addElement("35");
		f.addElement("90");
		System.out.println(f);


	}

}
