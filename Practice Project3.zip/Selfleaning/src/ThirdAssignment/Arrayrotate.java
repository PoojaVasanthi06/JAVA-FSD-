package ThirdAssignment;

public class Arrayrotate {

    public static void main(String[] args) {
        int[] array = {4, 9, 6, 1, 3, 6, 7, 8, 9};
        int steps = 5;

        System.out.println("Original Array: ");
        printArray(array);

        rightRotateArray(array, steps);

        System.out.println("\nArray after right rotation by " + steps + " steps: ");
        printArray(array);
    }

    static void rightRotateArray(int[] arr, int steps) {
        int length = arr.length;
        steps = steps % length;

        reverseArray(arr, 0, length - 1);  //0 8
        reverseArray(arr, 0, steps - 1); //0 4
        reverseArray(arr, steps, length - 1); // 5 8
    }

    static void reverseArray(int[] arr, int start, int end) {
        while (start < end) {      //0<8
            int temp = arr[start];      // temp=0  
            arr[start] = arr[end];    // a[0]=a[8]
            arr[end] = temp;          // a[8]=a[0]
            start++;                  // 
            end--;
        }
    }

    static void printArray(int[] arr) {
        for (int value : arr) {
            System.out.print(value + " ");
        }
        System.out.println();
    }
}
