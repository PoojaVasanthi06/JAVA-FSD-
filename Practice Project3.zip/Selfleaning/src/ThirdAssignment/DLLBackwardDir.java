package ThirdAssignment;

class Node2 {
    int data;
    Node2 next;
    Node2 prev;

    Node2(int data) {
        this.data = data;
        this.next = null;
        this.prev = null;
    }
}

class DoublyLinkedList {
    Node2 head;

    DoublyLinkedList() {
        this.head = null;
    }

    void append(int data) {
        Node2 newNode = new Node2(data);
        if (head == null) {
            head = newNode;
        } else {
            Node2 last = head;
            while (last.next != null) {
                last = last.next;
            }
            last.next = newNode;
            newNode.prev = last;
        }
    }

    void traverseForward() {
        System.out.println("Doubly Linked List (Forward):");
        Node2 current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

    void traverseBackward() {
        System.out.println("Doubly Linked List (Backward):");
        Node2 last = head;
        while (last.next != null) {
            last = last.next;
        }
        while (last != null) {
            System.out.print(last.data + " ");
            last = last.prev;
        }
        System.out.println();
    }
}

public class DLLBackwardDir {
    public static void main(String[] args) {
        DoublyLinkedList doublyList = new DoublyLinkedList();

        doublyList.append(1);
        doublyList.append(2);
        doublyList.append(3);
        doublyList.append(4);
        doublyList.append(5);

        doublyList.traverseForward();
        doublyList.traverseBackward();
    }
}


