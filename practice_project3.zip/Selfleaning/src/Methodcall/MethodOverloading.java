package Methodcall;

class A{
	void get() {
		System.out.println("Method overloading");
	}
	void get(int a, String s) {
		System.out.println("The entered Integer value is : "+a);
		System.out.println("The entered String value is : "+s);

	}
}
public class MethodOverloading {

	public static void main(String[] args) {
		A ob = new A();
		ob.get();
		ob.get(144,"hello World");
	}

}

