package SleepWait;
class CustomException extends Exception {
    public CustomException(String message) {
        super(message);
    }
}

public class ExceptionHandling {
    public static void main(String[] args) {
        try {
            throwException();
        } catch (CustomException ce) {
            System.out.println("Caught CustomException: " + ce.getMessage());
        } finally {
            System.out.println("Finally block is executed regardless of exceptions.");
        }
    }

    @SuppressWarnings("finally")
	private static void throwException() throws CustomException {
        try {
            throw new RuntimeException("Runtime exception occurred");
        } finally {
            System.out.println("This code runs in the finally block.");
            throw new CustomException("Custom exception thrown in finally block");
        }
    }
}