package Lesson3;

class A extends Thread{
	public void run() {
		System.out.println("Hello");
	}
}
public class Threadrun {

	public static void main(String[] args) {
		A ob = new A();
		ob.start();
	}

}
