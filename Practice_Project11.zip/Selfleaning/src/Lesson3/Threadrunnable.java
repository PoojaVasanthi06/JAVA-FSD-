package Lesson3;

class get implements Runnable{
	public void run() {
		for(int i=1;i<=10;i++) {
			System.out.println("Thread Implementation : "+i);
		}
	}
}
public class Threadrunnable {

	public static void main(String[] args) {

		get ob = new get();
		Thread t = new Thread(ob);
		t.start();
	}

}
