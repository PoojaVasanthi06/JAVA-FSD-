package Practice;
import java.util.*;

public class MapImplementation {

	public static void main(String[] args) {
	    System.out.println("HashMap");
		HashMap<Integer,String> Hap =new HashMap<Integer,String>();
		Hap.put(1,"100");
		Hap.put(2,"200");
		Hap.put(3,"300");
		Hap.put(4,"400");
		for(Map.Entry a : Hap.entrySet()) {
		System.out.println(a.getKey()+" "+a.getValue());
		}
		
		System.out.println("\nLinked HashMap");
		LinkedHashMap<Integer,String> lap = new LinkedHashMap<Integer,String>();
		lap.put(1,"100");
		lap.put(2,"200");
		lap.put(3,"300");
		lap.put(4,"400");
		for(Map.Entry b : lap.entrySet()) {
			System.out.println(b.getKey()+" "+b.getValue());
			}		
		
		System.out.println("\nTree Map");
		TreeMap<Integer,String> tree = new TreeMap<Integer,String>();
		tree.put(1,"100");
		tree.put(2,"200");
		tree.put(3,"300");
		tree.put(4,"400");
		for(Map.Entry c : tree.entrySet()) {
			System.out.println(c.getKey()+" "+c.getValue());
			}		

	}

}
