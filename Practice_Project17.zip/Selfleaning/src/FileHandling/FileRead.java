package FileHandling;

import java.io.*;
import java.util.Scanner;

public class FileRead {

	public static void main(String[] args) throws FileNotFoundException {
		File f = new File("C:\\Users\\project\\testFile1.txt");
		Scanner sc = new Scanner(System.in);
		while(sc.hasNextLine()) {
			String a = sc.nextLine();
			System.out.println(a);
		}
		sc.close();
		
	}

}
