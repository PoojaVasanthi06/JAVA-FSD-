package FileHandling;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Arrays;
import java.util.List;

public class FileCreateRead {

	    private static void createFileUsingFileClass() throws IOException {
		    File f = new File("C:\\Users\\project\\testFile1.txt");
		    if(f.createNewFile()) {
		    	System.out.println("File created successfully");
		    }
		    else {
			    System.out.println("File not created");
		    }
		    FileWriter fwrite = new FileWriter("C:\\Users\\project\\testFile1.txt");
		    fwrite.write("Sample file create and write using file handling");
		    fwrite.close();
	    }
	    
	    private static void createFileUsingStreamClass() throws IOException{
	    	String s = "Sample file create and write using file handling";
	    	FileOutputStream fout = new FileOutputStream("c://temp//testFile2.txt");
	    	fout.write(s.getBytes());
	    	fout.close();
	    }
	    
	    private static void createFileIn_NIO()  throws IOException{
	    	String s = "Sample file create and write using file handling";
	    	Files.write(Paths.get("C:\\Users\\project\\testFile3.txt"),s.getBytes());
	        List<String> lines = Arrays.asList("1st line", "2nd line");
	        Files.write(Paths.get("file6.txt"),
	                    lines,
	                    StandardCharsets.UTF_8,
	                    StandardOpenOption.CREATE,
	                    StandardOpenOption.APPEND);

	    }

	    
	 public static void main(String[] args) throws IOException {
		 createFileUsingFileClass();
		 createFileUsingStreamClass();
		 createFileIn_NIO();
		 
	 }

}
