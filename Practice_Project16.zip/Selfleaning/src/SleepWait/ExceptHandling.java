package SleepWait;

class NewException extends Exception{
	   String str1;
	   NewException(String str2) {
		str1=str2;
	   }
	   public String toString(){ 
		return ("NewException Occurred: "+str1) ;
	   }
	}
	class ExceptHandling{
	   public static void main(String args[]){
		try{
			System.out.println("Exception start from try block");
			throw new NewException("This is new error Message");
		}
		catch(NewException exp){
			System.out.println("Catch Block") ;
			System.out.println(exp) ;
		}
	   }
	}

