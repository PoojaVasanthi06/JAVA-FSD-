package PublicAccessSpecifier;

public class Access_specifier {

	 public void Sample() 
   { 
       System.out.println("This is Public access specifier"); 
   } 
}
