package ProtectedAccessSpecifier;

public class Access_specifier {

	protected void Sample() 
    { 
        System.out.println("This is protected access specifier"); 
    } 
}