package PublicAccess1;

import PublicAccessSpecifier.Access_specifier;

public class AccessModifier {

	public static void main(String[] args) {
		Access_specifier ob = new Access_specifier();
		ob.Sample();
	}

}