package AccessModifier;

class Sample{
	private void get() {
		System.out.println("Private Access Modifier");
	}
}

public class PrivateAccess {

	public static void main(String[] args) {
		Sample ob = new Sample();
		// ob.get(); // Can't execute private accsess specifier in other class
	}

}
