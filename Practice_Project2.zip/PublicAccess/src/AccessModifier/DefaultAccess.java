package AccessModifier;

class A{
	void get() {
		System.out.println("Default Access Modifier");
	}
}

public class DefaultAccess {

	public static void main(String[] args) {
		A ob = new A();
		ob.get();
	}

}
