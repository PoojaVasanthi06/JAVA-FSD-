package ProtectedAccess1;

import ProtectedAccessSpecifier.Access_specifier;

public class AccessModifier extends Access_specifier {

	public static void main(String[] args) {
		AccessModifier ob = new AccessModifier();
		ob.Sample();
	}

}
