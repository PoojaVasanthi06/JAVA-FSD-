package PhaseEnd1;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

class UserInfo {
    private String username;
    private String password;
    private double walletAmt;

    // Getter and setter methods...

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public double getWalletAmt() {
        return walletAmt;
    }

    public void setWalletAmt(double walletAmt) {
        this.walletAmt = walletAmt;
    }

    // AddAmtToWallet method...
    public void addAmtToWallet() {
        System.out.println("Current Wallet Balance: " + walletAmt);
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter Amount to Add to Wallet: ");
        double amount = scanner.nextDouble();
        walletAmt += amount;
        System.out.println("Amount Added Successfully. Total Wallet Amount: " + walletAmt);
    }
}

class Camera {
    private int camid;
    private String brand;
    private String model;
    private float rentPerDay;
    private String status;

    // Getter and setter methods...

    public int getCamid() {
        return camid;
    }

    public void setCamid(int camid) {
        this.camid = camid;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public float getRentPerDay() {
        return rentPerDay;
    }

    public void setRentPerDay(float rentPerDay) {
        this.rentPerDay = rentPerDay;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    // Constructor...

    public Camera(int camid, String brand, String model, float rentPerDay, String status) {
        this.camid = camid;
        this.brand = brand;
        this.model = model;
        this.rentPerDay = rentPerDay;
        this.status = status;
    }

    // toString method...

    @Override
    public String toString() {
        return "Camera ID: " + camid +
                ", Brand: " + brand +
                ", Model: " + model +
                ", Rent per Day: " + rentPerDay +
                ", Status: " + status;
    }
}

class CameraOperations {
    private List<Camera> rentACamera = new ArrayList<>();

    // Method to print camera details in a formatted box
    public void printCameraDetails(List<Camera> cameras) {
        System.out.println("-------------------------------------------------------------------------------------------");
        System.out.printf("%-15s%-20s%-20s%-25s%-15s%n", "CAMERA ID", "BRAND", "MODEL", "PRICE(PER DAY)", "STATUS");
        System.out.println("-------------------------------------------------------------------------------------------");

        for (Camera camera : cameras) {
            System.out.printf("%-15d%-20s%-20s%-25.2f%-15s%n",
                    camera.getCamid(), camera.getBrand(), camera.getModel(),
                    camera.getRentPerDay(), camera.getStatus());
        }

        System.out.println("-------------------------------------------------------------------------------------------");
    }

    // Method to print default camera details...
    public void printDefaultCameraDetails() {
        System.out.println("-------------------------------------------------------------------------------------------");
        System.out.printf("%-15s%-20s%-20s%-25s%-15s%n", "CAMERA ID", "BRAND", "MODEL", "PRICE(PER DAY)", "STATUS");
        System.out.println("-------------------------------------------------------------------------------------------");

        Camera[] defaultCameras = {
                new Camera(11, "Something", "some", 200.0f, "Rented"),
                new Camera(12, "Some", "Another", 100.0f, "Available"),
                new Camera(14, "NIKON", "OSLR-D7500", 500.0f, "Available"),
                new Camera(15, "Sony", "OSLR12", 200.0f, "Available"),
                new Camera(17, "Samsung", "SM123", 200.0f, "Available"),
                new Camera(19, "SONY", "SONY1234", 123.0f, "Available"),
                new Camera(20, "canon", "5050", 25000.0f, "Available"),
                new Camera(21, "nikon", "2030", 500.0f, "Available")
        };

        rentACamera.addAll(Arrays.asList(defaultCameras));

        for (Camera camera : defaultCameras) {
            System.out.printf("%-15d%-20s%-20s%-25.2f%-15s%n",
                    camera.getCamid(), camera.getBrand(), camera.getModel(),
                    camera.getRentPerDay(), camera.getStatus());
        }

        System.out.println("-------------------------------------------------------------------------------------------");
    }

    public String addCameras(Camera cm) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter Camera ID: ");
        int camid = scanner.nextInt();
        cm.setCamid(camid);

        scanner.nextLine(); // Consume newline left after nextInt()

        System.out.print("Enter Brand: ");
        String brand = scanner.nextLine();
        cm.setBrand(brand);

        System.out.print("Enter Model: ");
        String model = scanner.nextLine();
        cm.setModel(model);

        System.out.print("Enter Rent per Day: ");
        float rentPerDay = scanner.nextFloat();
        cm.setRentPerDay(rentPerDay);

        cm.setStatus("Available");

        rentACamera.add(cm);
        return "Camera Added Successfully.";
    }

    public List<Camera> showAllCameras() {
        Collections.sort(rentACamera, (c1, c2) -> Integer.compare(c1.getCamid(), c2.getCamid()));
        return rentACamera;
    }

    public String deleteCamera(int camid) {
        for (Camera camera : rentACamera) {
            if (camera.getCamid() == camid) {
                if ("Rented".equals(camera.getStatus())) {
                    return "Cannot delete a rented camera.";
                } else {
                    rentACamera.remove(camera);
                    return "Camera deleted successfully.";
                }
            }
        }
        return "Camera not found.";
    }

    public void rentACamera(int camid, double walletAmt) {
        System.out.println("List of Available Cameras:");
        for (Camera camera : rentACamera) {
            if ("Available".equals(camera.getStatus())) {
                System.out.println(camera.toString());
            }
        }

        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter Camera ID to Rent: ");
        int selectedCamId = scanner.nextInt();

        for (Camera camera : rentACamera) {
            if (camera.getCamid() == selectedCamId && "Available".equals(camera.getStatus())) {
                if (walletAmt >= camera.getRentPerDay()) {
                    walletAmt -= camera.getRentPerDay();
                    camera.setStatus("Rented");
                    System.out.println("Camera rented successfully. Wallet Balance: " + walletAmt);
                } else {
                    System.out.println("Insufficient funds in the wallet.");
                }
                return;
            }
        }

        System.out.println("Invalid Camera ID or Camera already rented.");
    }
}

public class CameraRentalApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        UserInfo user = new UserInfo();
        user.setUsername("admin");
        user.setPassword("admin@123");
        user.setWalletAmt(10000.00);

        System.out.print("Enter username: ");
        String inputUsername = scanner.next();
        System.out.print("Enter Password: ");
        String inputPassword = scanner.next();

        if ("admin".equals(inputUsername) && "admin@123".equals(inputPassword)) {
            CameraOperations cameraOperations = new CameraOperations();

            // Print default camera details
            cameraOperations.printDefaultCameraDetails();

            while (true) {
                System.out.println("1. My Camera");
                System.out.println("2. Rent A Camera");
                System.out.println("3. View All Cameras");
                System.out.println("4. My Wallet");
                System.out.println("5. Exit");
                System.out.print("Enter your choice: ");
                int choice = scanner.nextInt();

                switch (choice) {
                    case 1:
                        while (true) {
                            System.out.println("1. Add Camera");
                            System.out.println("2. Remove Camera");
                            System.out.println("3. View Cameras");
                            System.out.println("4. Back to Main Menu");
                            System.out.print("Enter your choice: ");
                            int subChoice = scanner.nextInt();

                            switch (subChoice) {
                                case 1:
                                    Camera newCamera = new Camera(0, "", "", 0.0f, ""); // provide appropriate values
                                    // Set camera details using scanner input
                                    System.out.println(cameraOperations.addCameras(newCamera));
                                    break;
                                case 2:
                                    System.out.print("Enter Camera ID to Delete: ");
                                    int camIdToDelete = scanner.nextInt();
                                    System.out.println(cameraOperations.deleteCamera(camIdToDelete));
                                    break;
                                case 3:
                                    System.out.println("All Cameras:");
                                    List<Camera> allCameras = cameraOperations.showAllCameras();
                                    cameraOperations.printCameraDetails(allCameras);
                                    break;
                                case 4:
                                    break;
                                default:
                                    System.out.println("Invalid choice. Please try again.");
                            }

                            if (subChoice == 4) {
                                break;
                            }
                        }
                        break;
                    case 2:
                        cameraOperations.rentACamera(1, user.getWalletAmt()); // Example camid = 1
                        break;
                    case 3:
                        System.out.println("All Cameras:");
                        List<Camera> allCameras = cameraOperations.showAllCameras();
                        cameraOperations.printCameraDetails(allCameras);
                        break;
                    case 4:
                        user.addAmtToWallet();
                        break;
                    case 5:
                        System.out.println("Exiting the application.");
                        System.exit(0);
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            }
        } else {
            System.out.println("Incorrect username/password.");
        }
    }
}
