package Practice;
class Demo{
	Demo() {
		System.out.println("Default/Normal Constructor");
	}
	Demo(String s){
		System.out.println(s);
	}
}
public class ConstructorTypes {

	public static void main(String[] args) {
		Demo ob=new Demo();
		Demo ob1 = new Demo("parameterized constructor ");

	}

}
