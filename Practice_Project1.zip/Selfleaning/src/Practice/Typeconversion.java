package Practice;

public class Typeconversion {

	public static void main(String[] args) {
		System.out.println("Implicit Type Conversion :");
		System.out.println("Type conversion for character 'M' : ");
	    char x = 'M';
	    int a = x;
	    System.out.println("Integer value : "+a);
	    long b = a;
	    System.out.println("Long value : "+b);
	    float c = b;
	    System.out.println("Float value : "+c);
	    double d = c;
	    System.out.println("Double value : "+d);
	    
	    System.out.println("\nExplicit Type Conversion : ");
	    int m = 70;
	    System.out.println("Integer value : "+m);
	    char n = (char)m;
	    System.out.println("character value : "+n);
	    
	    double p = 95.5;
	    System.out.println("\nDouble value : "+p);
	    int q = (int)p ;
	    System.out.println("Integer value : "+q);


	}

}
