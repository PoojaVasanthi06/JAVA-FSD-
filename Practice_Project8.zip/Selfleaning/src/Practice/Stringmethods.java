package Practice;

public class Stringmethods {
	public static void main(String[] args) {

	//methods of strings	
	String stg=new String("Hello World");
	System.out.println("length : "+stg.length());

	//substring
	System.out.println("SubString : "+stg.substring(6));

	//String Comparison
	String s1="Comparison";
	String s2="Comparison";
	System.out.println("Comparison : "+s1.compareTo(s2));

	//IsEmpty
	String s3="IsEmpty";
	System.out.println("If String is Empty : "+s3.isEmpty());

	//toLowerCase
	String s4="JaVa";
	System.out.println("Lower case : "+s4.toLowerCase());
	System.out.println("Uppercase : "+s4.toUpperCase());
	
	//replace
	String s5="Welcame";
	System.out.println("Before replace : "+s5);
	String replace=s5.replace('a', 'o');
	System.out.println("After replace : "+replace);

	//equals
	String x="Welcome to Java";
	String y="WeLcomE to JAVA";
	System.out.println("String equals with case sensitive : "+x.equals(y));
	System.out.println("String equals without case sensitive : "+x.equalsIgnoreCase(y));

	System.out.println("\nCreating String Buffer :");
	StringBuffer s=new StringBuffer("Mphasis");
	s.append(" Learning Accademy");
	System.out.println("\nString Buffer : "+s);

	//insert method
	s.insert(0, 'M');
	System.out.println("Insering new character : "+s);

	//replace method
	s.replace(0, 8, "Simple");
	System.out.println("Replace String : "+s);

	//delete method
	s.delete(0, 7);
	System.out.println("Delete String : "+s);

	System.out.println("\nCreating StringBuilder :");
	StringBuilder sb1=new StringBuilder("Happy");
	sb1.append(" Learning");
	System.out.println("\nString Builder : "+sb1);

	System.out.println("Delete String : "+sb1.delete(0, 6));

	System.out.println("Insering String : "+sb1.insert(0, "Happy "));

	System.out.println("String reverse : "+sb1.reverse());
	
			
	System.out.println("\nConversion of Strings to StringBuffer and StringBuilder");
	String str = "Simplilearn platform"; 
   
    // conversion from String object to StringBuffer 
    StringBuffer sbr = new StringBuffer(str); 
    System.out.println("String to StringBuffer(String reverse) : "+sbr.reverse()); 

    // conversion from String object to StringBuilder 
    StringBuilder sbl = new StringBuilder(str); 
    sbl.append(" Accademy"); 
    System.out.println("String to StringBuilder(Insert string) : "+sbl);              
	}
}
