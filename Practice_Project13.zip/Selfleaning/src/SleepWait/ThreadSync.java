package SleepWait;

class Sender 
{ 
    public void send(String st) 
    { 
        System.out.println("\nSending\t"  + st ); 
        try
        { 
            Thread.sleep(2000); 
        } 
        catch (Exception e) 
        { 
            System.out.println("Thread  interrupted."); 
        } 
        System.out.println("\n" + st + "Sent"); 
    } 
} 
class ThreadedSend extends Thread 
{ 
     String st; 
    
    Sender  sender; 
    ThreadedSend(String m,  Sender obj) 
    { 
        st = m; 
        sender = obj; 
    } 
  
    public void run() 
    {  
        synchronized(sender) 
        { 
            sender.send(st); 
        } 
    } 
} 
class ThreadSync 
{ 
    public static void main(String args[]) 
    { 
        Sender snd = new Sender(); 
        ThreadedSend S1 = new ThreadedSend( " Hi " , snd ); 
        ThreadedSend S2 = new ThreadedSend( " Bye " , snd ); 
            
        S1.start(); 
        S2.start(); 
        try
        { 
            S1.join(); 
            S2.join(); 
        } 
        catch(Exception e) 
        { 
            System.out.println("Interrupted"); 
        } 
    } 
} 
