package polymorphism;

class A{
	void get() {
		System.out.println("Mathod Over Riding");
	}
}
class B extends A{
void get() {
	super.get();
		System.out.println("Both super and subclass having same method name same parameter");
	}
}

public class MethodOverriding {

	public static void main(String[] args) {
		B ob = new B();
		ob.get();
	}

}
