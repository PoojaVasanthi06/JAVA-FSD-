package polymorphism;

class Example{
	void get() {
		System.out.println("Mathod overloading");
	}
	void get(String a) {
		System.out.println(a);
	}
	void get(int b, String c) {
		System.out.println(b);
		System.out.println(c);
	}
}

public class MathodOverloading {

	public static void main(String[] args) {
		Example ob = new Example();
		ob.get();
		ob.get("Same Method Name Different Parameter");
		ob.get(50, "Hello World");
	}

}
