package ClassObj;

public class ClassObjects 
{  
    String Emp_Name; 
    String Emp_dep;; 
    int YearOf_Experience; 
    String Location; 
    public ClassObjects(String Emp_Name, String Emp_dep, int YearOf_Experience, String Location) 
    { 
        this.Emp_Name = Emp_Name; 
        this.Emp_dep = Emp_dep; 
        this.YearOf_Experience = YearOf_Experience; 
        this.Location = Location; 
    } 
    public String getEmp_Name() 
    { 
        return Emp_Name; 
    } 
    public String getEmp_dep() 
    { 
        return Emp_dep; 
    } 
    public int getYearOf_Experience() 
    { 
        return YearOf_Experience; 
    } 
    public String getLocation() 
    { 
        return Location; 
    } 
    @Override
    public String toString() 
    { 
        return("Hi my name is "+ this.getEmp_Name()+ ".\nMy deparment, Year of Experience and Location are : " + this.getEmp_dep()+", " + this.getYearOf_Experience()+ ", and "+ this.getLocation() + "."); 
    } 
    public static void main(String[] args) 
    { 
        ClassObjects scott = new ClassObjects("Mythika","Software Developer", 2, "Chennai"); 
        System.out.println(scott.toString()); 
    } 
}
