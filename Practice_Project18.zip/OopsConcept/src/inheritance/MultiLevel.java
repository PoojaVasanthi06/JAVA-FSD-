package inheritance;

class G{
	void get() {
		System.out.println("Single level Inheritance");
	}
}
class F extends G{
void get() {
	super.get();
		System.out.println("more than one super class and one sub class");
	}
}
class H extends F{
void get() {
	super.get();
		System.out.println("Need to create object for last sub class only");
	}
}

public class MultiLevel {

	public static void main(String[] args) {
		H ob = new H();
		ob.get();
	}

}
