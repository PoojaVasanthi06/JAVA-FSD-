package inheritance;

class A{
	void get() {
		System.out.println("Single level Inheritance");
	}
}
class B extends A{
void get() {
	super.get();
		System.out.println("One super class and one sub class");
	}
}

public class SingleLevel {

	public static void main(String[] args) {
		B ob = new B();
		ob.get();
	}

}
